import wpilib.interfaces


def test_wpilib_interfaces():
    pass
