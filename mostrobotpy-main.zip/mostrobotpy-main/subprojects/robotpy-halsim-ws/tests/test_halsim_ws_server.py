# tests the internals
import halsim_ws.server._init_server


def test_halsim_ws_server():
    pass
