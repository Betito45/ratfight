# tests the internals
import halsim_ws.client._init_client


def test_halsim_ws_client():
    pass
