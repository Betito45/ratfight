import cscore


def test_cscore_import():
    pass
