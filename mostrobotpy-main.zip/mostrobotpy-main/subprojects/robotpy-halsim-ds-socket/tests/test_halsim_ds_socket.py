# tests the internals
import halsim_ds_socket._init_halsim_ds_socket


def test_halsim_ds_socket():
    pass
