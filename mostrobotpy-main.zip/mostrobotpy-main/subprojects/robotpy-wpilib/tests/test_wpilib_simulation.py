import wpilib.simulation


def test_wpilib_simulation():
    pass
