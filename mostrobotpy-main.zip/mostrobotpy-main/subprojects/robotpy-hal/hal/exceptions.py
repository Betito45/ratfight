class HALError(RuntimeError):
    pass
