cscore.imagewriter Package
===========================

.. automodule:: cscore.imagewriter
    :members:
